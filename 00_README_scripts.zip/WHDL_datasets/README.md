# Datasets — Forest Wildfire and Wildlife Monitoring (WHDL project)

Everything here is real, publicly released data, cleaned and arranged so the code described in
your report (Ch. 7) can train on it directly. The one exception is the `fire_animal` part of
`fusion_test/`, which is synthetic and clearly marked.

```
datasets/
├── fire_dataset/          -> VGG19 fire classifier   (Keras folder format)
├── wildlife_dataset/      -> YOLOv5 animal detector  (YOLO txt format + data.yaml)
├── fusion_test/           -> hypergraph fusion evaluation (4 scenarios, labelled)
└── scripts/               -> download more data (Kaggle fire, full COCO animals) + rebuild scripts
```

All images were checked to open correctly, de-duplicated (85 duplicates removed) and resized so
the longest side is at most 640 px (VGG19 uses 224 px and YOLOv5 640 px, so no useful detail is lost).

---

## 1. `fire_dataset/` — for VGG19 (report §4.3, §7.3)

| Folder | fire | non_fire | Source | Use |
|---|---|---|---|---|
| `train/` | 682 | 718 | DeepQuest AI | training |
| `val/` | 160 | 180 | DeepQuest AI | 20% validation (report §7.3) |
| `test/` | 98 | 100 | DeepQuest AI (official test split) | balanced test |
| `test_real_world/` | 109 | 539 | CAIR Fire-Detection-Image-Dataset | hard, unbalanced test: negatives are rooms, streets, landscapes, sunsets and warm indoor lighting |
| `extra_smoke/` | 993 smoke-only images | | DeepQuest AI | optional 3rd class "smoke" |

`manifest.csv` lists every image with its split, label, source and original file name.

Load it in Keras:
```python
import tensorflow as tf
train = tf.keras.utils.image_dataset_from_directory("fire_dataset/train", image_size=(224, 224),
                                                    batch_size=32, label_mode="categorical")
val   = tf.keras.utils.image_dataset_from_directory("fire_dataset/val",   image_size=(224, 224),
                                                    batch_size=32, label_mode="categorical")
# classes come out as ['fire', 'non_fire']
```

**Match your report exactly:** Table 4.2 describes the Kaggle FIRE dataset (999 images: 755 fire,
244 non-fire). Kaggle needs your own API key, so run `python scripts/download_kaggle_fire.py`
once — it adds those images into `train/` and `val/` without duplicates.

**Be aware:** DeepQuest fires are general fires (houses, rooms, vehicles, a few game screenshots),
not only forests. CAIR adds more outdoor scenes. If your examiner asks, describe the training data
as "general fire imagery" unless you add the Kaggle set (which is mostly forest/outdoor).

## 2. `wildlife_dataset/` — for YOLOv5 (report §4.2, §7.4)

YOLO format: `images/<split>/x.jpg` + `labels/<split>/x.txt` (`class x_center y_center w h`, normalised).

| Split | Images | Boxes per class |
|---|---|---|
| train | 1,079 | elephant 575, zebra 579, buffalo 399, rhino 399, + a few COCO animals |
| val | 225 | elephant 91, zebra 114, buffalo 89, rhino 85 |
| test | 227 | elephant 99, zebra 135, buffalo 66, rhino 75 |

12 classes (in `data.yaml`): `bird cat dog horse sheep cow elephant bear zebra giraffe buffalo rhino`
— the 10 COCO animal classes from your Table 4.1 plus buffalo and rhino.

**Important:** right now the 8 COCO classes (bird … giraffe, except elephant/zebra) only have a
handful of boxes from COCO128. To fill them, run on your computer:

```bash
pip install requests pillow
python scripts/download_coco_animals.py --max-per-class 800   # ~6k images, balanced
python scripts/download_coco_animals.py                       # or all ~25k COCO animal images
```

It downloads only the animal images (not all 19 GB of COCO), converts boxes to YOLO, and drops
person/vehicle boxes. Then train:

```bash
git clone https://github.com/ultralytics/yolov5 && cd yolov5 && pip install -r requirements.txt
python train.py --data ../wildlife_dataset/data.yaml --weights yolov5s.pt --img 640 --batch 16 --epochs 100
```
(If YOLOv5 can't find the images, change `path: .` in `data.yaml` to the full folder path.)

## 3. `fusion_test/` — for the hypergraph fusion module (report §7.5, §8.2 confusion matrix)

| Scenario | Count | has_fire | has_animal | Real? |
|---|---|---|---|---|
| `fire_animal` | 200 | 1 | 1 | **Synthetic** — a real animal photo pasted into a real fire photo |
| `fire_only` | 100 | 1 | 0 | real |
| `animal_only` | 100 | 0 | 1 | real |
| `none` | 100 | 0 | 0 | real |

`fusion_labels.csv` gives the ground truth per image; `labels/` has YOLO boxes for every animal
(also for the pasted ones), so you can score both the detectors and the fused "Critical: Fire and
Animal Nearby" decision. All images come from **test** splits only, so nothing overlaps training.

Real photos of animals inside wildfires are rare and mostly copyrighted news photos. Use the
synthetic set to check that your pipeline and fusion rules work; in the report, say the
fire+animal cases were composited, and don't present those numbers as field accuracy.

## 4. Data your report mentions but the implementation does not use

Chapter 4.4 lists historical and ecological data. Your Chapter 7 code only uses images, so these
are optional. If you want to add a "fire history" or weather layer later:

- NASA FIRMS active fire data (India coverage, CSV/shapefile, free key): https://firms.modaps.eosdis.nasa.gov/download/
- MTBS burn severity (US): https://www.mtbs.gov/direct-download
- Canadian National Fire Database: https://cwfis.cfs.nrcan.gc.ca/ha/nfdb
- USGS Breeding Bird Survey: https://www.pwrc.usgs.gov/bbs/
- Movebank animal GPS tracking: https://www.movebank.org/

Several numbers in your report (e.g. 15,000 RGB + 5,000 thermal images, 50+ species, data from
conservation-organisation partnerships, A100 training) aren't backed by any dataset here. Update
those sections to the counts above before submission, so the report matches what you actually used.

## Sources and licences

| Dataset | Link | Licence |
|---|---|---|
| DeepQuest AI Fire-Smoke-Dataset | https://github.com/DeepQuestAI/Fire-Smoke-Dataset | none stated — academic use, cite the repo |
| CAIR Fire-Detection-Image-Dataset | https://github.com/cair/Fire-Detection-Image-Dataset | none stated — academic use, cite the repo |
| Ultralytics African Wildlife | https://docs.ultralytics.com/datasets/detect/african-wildlife/ | AGPL-3.0 |
| COCO 2017 / COCO128 | https://cocodataset.org | annotations CC BY 4.0, images under Flickr terms |
| Kaggle FIRE dataset (via script) | https://www.kaggle.com/datasets/phylake1337/fire-dataset | see Kaggle page |

## Rebuilding from scratch

`scripts/build_fire.py`, `build_wildlife.py` and `build_fusion.py` are the exact scripts used to make
these folders, in case you need to change the split or image size.
