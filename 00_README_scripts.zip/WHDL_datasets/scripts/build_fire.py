"""Build the VGG19 fire classification dataset.

Sources:
  DeepQuest AI Fire-Smoke-Dataset (Train: 900 Fire / 900 Smoke / 900 Neutral, Test: 100 each)
  CAIR Fire-Detection-Image-Dataset (110 fire / 541 normal; deliberately unbalanced, real-world)

Output (Keras image_dataset_from_directory / flow_from_directory layout):
  fire_dataset/train/{fire,non_fire}
  fire_dataset/val/{fire,non_fire}
  fire_dataset/test/{fire,non_fire}             <- DeepQuest held-out test
  fire_dataset/test_real_world/{fire,non_fire}  <- CAIR, unbalanced, hard negatives
  fire_dataset/extra_smoke/{train,test}         <- smoke-only images (optional 3rd class)
"""
import hashlib, random, sys, csv
from pathlib import Path
from PIL import Image, ImageOps

SRC = Path(sys.argv[1])   # extracted downloads
OUT = Path(sys.argv[2])   # output root
MAX_SIDE = 640
random.seed(42)
seen = set()
manifest = []

def images(folder):
    return sorted(p for p in Path(folder).rglob("*")
                  if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp"})

def save(src, dst_dir, prefix, split, label, source):
    """Open, verify, dedupe, resize, save as JPEG. Returns True if kept."""
    try:
        raw = src.read_bytes()
        im = Image.open(src); im.verify()
        im = Image.open(src); im = ImageOps.exif_transpose(im).convert("RGB")
    except Exception:
        return False
    # dedupe on decoded pixels of an 64x64 thumbnail (catches re-encoded copies)
    h = hashlib.md5(im.resize((64, 64)).tobytes()).hexdigest()
    if h in seen:
        return False
    seen.add(h)
    if max(im.size) > MAX_SIDE:
        im.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
    dst_dir.mkdir(parents=True, exist_ok=True)
    name = f"{prefix}_{len(manifest):05d}.jpg"
    im.save(dst_dir / name, quality=92)
    manifest.append([str((dst_dir / name).relative_to(OUT)), split, label, source, src.name, *im.size])
    return True

dq = SRC / "FIRE-SMOKE-DATASET/FIRE-SMOKE-DATASET"
cair = SRC / "cair"
fd = OUT / "fire_dataset"

# 1) DeepQuest held-out test first, so duplicates are removed from TRAIN, never from test
for cls, label in [("Fire", "fire"), ("Neutral", "non_fire")]:
    for p in images(dq / "Test" / cls):
        save(p, fd / "test" / label, "dq", "test", label, "DeepQuest")
for p in images(dq / "Test" / "Smoke"):
    save(p, fd / "extra_smoke" / "test", "dq", "test", "smoke", "DeepQuest")

# 2) CAIR real-world test
for p in images(cair / "Fire images"):
    save(p, fd / "test_real_world" / "fire", "cair", "test_real_world", "fire", "CAIR")
for i in range(1, 6):
    for p in images(cair / f"Normal Images {i}"):
        save(p, fd / "test_real_world" / "non_fire", "cair", "test_real_world", "non_fire", "CAIR")

# 3) DeepQuest Train -> 80% train / 20% val (matches report section 7.3)
for cls, label in [("Fire", "fire"), ("Neutral", "non_fire")]:
    ps = images(dq / "Train" / cls)
    random.shuffle(ps)
    cut = int(len(ps) * 0.8)
    for p in ps[:cut]:
        save(p, fd / "train" / label, "dq", "train", label, "DeepQuest")
    for p in ps[cut:]:
        save(p, fd / "val" / label, "dq", "val", label, "DeepQuest")
for p in images(dq / "Train" / "Smoke"):
    save(p, fd / "extra_smoke" / "train", "dq", "train", "smoke", "DeepQuest")

with open(fd / "manifest.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["path", "split", "label", "source", "original_name", "width", "height"])
    w.writerows(manifest)
print("kept", len(manifest), "images")
