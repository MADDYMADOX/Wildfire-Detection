"""Build the YOLOv5 wildlife detection dataset with one unified 12-class scheme.

Class scheme (also used by download_coco_animals.py so full COCO can be merged in later):
  0 bird 1 cat 2 dog 3 horse 4 sheep 5 cow 6 elephant 7 bear 8 zebra 9 giraffe 10 buffalo 11 rhino
"""
import sys, shutil
from pathlib import Path
from PIL import Image, ImageOps

SRC = Path(sys.argv[1]); OUT = Path(sys.argv[2]) / "wildlife_dataset"
NAMES = ["bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "buffalo", "rhino"]
AFRICAN = {0: 10, 1: 6, 2: 11, 3: 8}                       # buffalo, elephant, rhino, zebra
COCO = {14: 0, 15: 1, 16: 2, 17: 3, 18: 4, 19: 5, 20: 6, 21: 7, 22: 8, 23: 9}
MAX_SIDE = 640
counts = {}

def put(img_path, lbl_path, split, remap, prefix):
    lines = []
    for ln in lbl_path.read_text().split("\n"):
        parts = ln.split()
        if len(parts) != 5:
            continue
        c = int(float(parts[0]))
        if c not in remap:
            continue                      # drop non-animal COCO boxes (person, car, ...)
        x, y, w, h = map(float, parts[1:])
        if not (0 <= x <= 1 and 0 <= y <= 1 and 0 < w <= 1 and 0 < h <= 1):
            continue
        lines.append(f"{remap[c]} {x:.6f} {y:.6f} {w:.6f} {h:.6f}")
    if not lines:
        return
    try:
        im = ImageOps.exif_transpose(Image.open(img_path)).convert("RGB")
    except Exception:
        return
    if max(im.size) > MAX_SIDE:            # uniform resize keeps normalised YOLO boxes valid
        im.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
    stem = f"{prefix}_{img_path.stem.replace(' ', '_').replace('(', '').replace(')', '')}"
    (OUT / "images" / split).mkdir(parents=True, exist_ok=True)
    (OUT / "labels" / split).mkdir(parents=True, exist_ok=True)
    im.save(OUT / "images" / split / f"{stem}.jpg", quality=92)
    (OUT / "labels" / split / f"{stem}.txt").write_text("\n".join(lines) + "\n")
    counts[split] = counts.get(split, 0) + 1

aw = SRC / "african-wildlife"
for split in ["train", "val", "test"]:
    for img in sorted((aw / "images" / split).iterdir()):
        lbl = aw / "labels" / split / (img.stem + ".txt")
        if lbl.exists():
            put(img, lbl, split, AFRICAN, "aw")

c128 = SRC / "coco128/coco128"
for img in sorted((c128 / "images/train2017").iterdir()):
    lbl = c128 / "labels/train2017" / (img.stem + ".txt")
    if lbl.exists():
        put(img, lbl, "train", COCO, "coco")

yaml = f"""# Wildlife detection dataset for YOLOv5  (train: python train.py --data data.yaml --img 640)
path: .   # set to the absolute path of this folder if YOLOv5 can't find it
train: images/train
val: images/val
test: images/test

nc: {len(NAMES)}
names: {NAMES}
"""
(OUT / "data.yaml").write_text(yaml)
print(counts)
