"""Download the 10 COCO-2017 animal classes your report lists (Table 4.1) and add them to
wildlife_dataset/ in YOLO format, using the same 12-class scheme as data.yaml.

  pip install requests pillow
  python scripts/download_coco_animals.py                     # everything (~25k images, ~4 GB)
  python scripts/download_coco_animals.py --max-per-class 800 # smaller, more balanced subset

Only images that contain at least one of the animal classes are downloaded (not the whole 19 GB COCO).
Re-running is safe: images already on disk are skipped.
"""
import argparse, io, json, random, zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import requests
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
WD = ROOT / "wildlife_dataset"
CACHE = ROOT / "_coco_tmp"
ANN_URL = "http://images.cocodataset.org/annotations/annotations_trainval2017.zip"
# COCO category id -> our class id   (bird cat dog horse sheep cow elephant bear zebra giraffe)
CAT_MAP = {16: 0, 17: 1, 18: 2, 19: 3, 20: 4, 21: 5, 22: 6, 23: 7, 24: 8, 25: 9}

def get_annotations():
    CACHE.mkdir(exist_ok=True)
    z = CACHE / "annotations_trainval2017.zip"
    if not z.exists():
        print("Downloading COCO annotations (241 MB) ...")
        with requests.get(ANN_URL, stream=True, timeout=60) as r:
            r.raise_for_status()
            with open(z, "wb") as f:
                for chunk in r.iter_content(1 << 20):
                    f.write(chunk)
    zf = zipfile.ZipFile(z)
    return {s: json.loads(zf.read(f"annotations/instances_{s}2017.json")) for s in ("train", "val")}

def build_jobs(data, max_per_class, seed=0):
    imgs = {im["id"]: im for im in data["images"]}
    per_img = {}
    for a in data["annotations"]:
        if a["category_id"] in CAT_MAP and not a.get("iscrowd", 0):
            per_img.setdefault(a["image_id"], []).append(a)
    ids = list(per_img)
    random.Random(seed).shuffle(ids)
    if max_per_class:
        count, keep = {c: 0 for c in CAT_MAP.values()}, []
        for i in ids:
            cls = {CAT_MAP[a["category_id"]] for a in per_img[i]}
            if any(count[c] < max_per_class for c in cls):
                keep.append(i)
                for c in cls:
                    count[c] += 1
        ids = keep
    jobs = []
    for i in ids:
        im = imgs[i]; W, H = im["width"], im["height"]
        lines = []
        for a in per_img[i]:
            x, y, w, h = a["bbox"]
            if w < 2 or h < 2:
                continue
            lines.append(f"{CAT_MAP[a['category_id']]} {(x + w/2)/W:.6f} {(y + h/2)/H:.6f} {w/W:.6f} {h/H:.6f}")
        if lines:
            jobs.append((im["coco_url"], im["file_name"], lines))
    return jobs

def fetch(job, split):
    url, name, lines = job
    stem = "cocofull_" + Path(name).stem
    img_out = WD / "images" / split / f"{stem}.jpg"
    if img_out.exists():
        return "skip"
    try:
        r = requests.get(url, timeout=30); r.raise_for_status()
        im = Image.open(io.BytesIO(r.content)).convert("RGB")
        im.thumbnail((640, 640))
        im.save(img_out, quality=92)
        (WD / "labels" / split / f"{stem}.txt").write_text("\n".join(lines) + "\n")
        return "ok"
    except Exception as e:
        return f"fail {name}: {e}"

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-per-class", type=int, default=0, help="cap images per class (0 = no cap)")
    ap.add_argument("--workers", type=int, default=16)
    args = ap.parse_args()
    ann = get_annotations()
    for coco_split, our_split in (("train", "train"), ("val", "val")):
        cap = args.max_per_class if coco_split == "train" else (args.max_per_class // 5 if args.max_per_class else 0)
        jobs = build_jobs(ann[coco_split], cap)
        (WD / "images" / our_split).mkdir(parents=True, exist_ok=True)
        (WD / "labels" / our_split).mkdir(parents=True, exist_ok=True)
        print(f"COCO {coco_split}: {len(jobs)} animal images -> wildlife_dataset/{our_split}")
        done = fail = 0
        with ThreadPoolExecutor(args.workers) as ex:
            for res in ex.map(lambda j: fetch(j, our_split), jobs):
                done += 1
                if res.startswith("fail"):
                    fail += 1
                if done % 500 == 0:
                    print(f"  {done}/{len(jobs)}  ({fail} failed)")
        print(f"  finished: {done - fail} ok, {fail} failed")
    print("Done. Delete", CACHE, "if you need the space.")
