"""Download the Kaggle FIRE dataset your report describes (Table 4.2: 999 images, 755 fire / 244 non-fire)
and merge it into fire_dataset/ with an 80/20 train/val split.

One-time setup:
  1. pip install kaggle pillow
  2. kaggle.com -> your profile -> Settings -> API -> "Create New Token"  (downloads kaggle.json)
  3. Put kaggle.json in  C:\\Users\\<you>\\.kaggle\\  (Windows)  or  ~/.kaggle/  (Linux/Mac)

Run from the folder that contains fire_dataset/:
  python scripts/download_kaggle_fire.py
"""
import hashlib, random, subprocess, sys, zipfile
from pathlib import Path
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent.parent
FD = ROOT / "fire_dataset"
TMP = ROOT / "_kaggle_tmp"
SLUG = "phylake1337/fire-dataset"
random.seed(42)

TMP.mkdir(exist_ok=True)
print("Downloading", SLUG, "...")
subprocess.run([sys.executable, "-m", "kaggle", "datasets", "download", "-d", SLUG, "-p", str(TMP)], check=True)
for z in TMP.glob("*.zip"):
    zipfile.ZipFile(z).extractall(TMP)

# existing images, so we don't add duplicates of DeepQuest pictures
seen = set()
for p in FD.rglob("*.jpg"):
    try:
        seen.add(hashlib.md5(Image.open(p).convert("RGB").resize((64, 64)).tobytes()).hexdigest())
    except Exception:
        pass

def find(name):
    hits = [d for d in TMP.rglob("*") if d.is_dir() and d.name.lower() == name]
    if not hits:
        sys.exit(f"Could not find folder '{name}' in the download - check the dataset layout.")
    return hits[0]

added = {"fire": 0, "non_fire": 0}
for folder, label in [("fire_images", "fire"), ("non_fire_images", "non_fire")]:
    files = sorted(p for p in find(folder).iterdir() if p.suffix.lower() in {".png", ".jpg", ".jpeg"})
    print(f"{folder}: {len(files)} images in download")
    random.shuffle(files)
    cut = int(len(files) * 0.8)
    for i, p in enumerate(files):
        try:
            im = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
        except Exception:
            continue
        h = hashlib.md5(im.resize((64, 64)).tobytes()).hexdigest()
        if h in seen:
            continue
        seen.add(h)
        im.thumbnail((640, 640), Image.LANCZOS)
        split = "train" if i < cut else "val"
        out = FD / split / label
        out.mkdir(parents=True, exist_ok=True)
        im.save(out / f"kaggle_{label}_{i:04d}.jpg", quality=92)
        added[label] += 1

print("Added:", added)
print("You can delete", TMP, "now.")
