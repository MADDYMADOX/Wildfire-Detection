"""Build a scenario-labelled test set for the hypergraph fusion module.

Scenarios: fire_animal (SYNTHETIC composite), fire_only, animal_only, none (all real photos).
Uses only TEST-split images so nothing here leaks into training.
"""
import sys, csv, random
from pathlib import Path
from PIL import Image, ImageFilter

ROOT = Path(sys.argv[1])                     # the output root holding fire_dataset & wildlife_dataset
FD, WD, OUT = ROOT / "fire_dataset", ROOT / "wildlife_dataset", ROOT / "fusion_test"
random.seed(7)
(OUT / "images").mkdir(parents=True, exist_ok=True)
(OUT / "labels").mkdir(parents=True, exist_ok=True)
rows = []

fire_imgs = sorted((FD / "test/fire").glob("*.jpg")) + sorted((FD / "test_real_world/fire").glob("*.jpg"))
nofire_imgs = sorted((FD / "test/non_fire").glob("*.jpg")) + sorted((FD / "test_real_world/non_fire").glob("*.jpg"))
animal_imgs = sorted((WD / "images/test").glob("*.jpg"))

def boxes(img_path):
    lbl = WD / "labels/test" / (img_path.stem + ".txt")
    return [ln.split() for ln in lbl.read_text().split("\n") if ln.strip()]

def add(name, im, scenario, labels, synthetic, src):
    im.save(OUT / "images" / name, quality=92)
    (OUT / "labels" / (Path(name).stem + ".txt")).write_text("".join(l + "\n" for l in labels))
    rows.append([name, scenario, int("fire" in scenario), int("animal" in scenario),
                 "yes" if synthetic else "no", src])

# --- fire_animal: paste one real animal crop into a real fire photo ---------------
crops = []
for p in animal_imgs:
    im = Image.open(p).convert("RGB"); W, H = im.size
    for c, x, y, w, h in boxes(p):
        x, y, w, h = map(float, (x, y, w, h))
        if 0.04 < w * h < 0.5:                     # skip tiny or full-frame animals
            pad = 0.06
            l, t = max(0, (x - w/2 - pad*w) * W), max(0, (y - h/2 - pad*h) * H)
            r, b = min(W, (x + w/2 + pad*w) * W), min(H, (y + h/2 + pad*h) * H)
            # true animal box inside the crop, as fractions of the crop
            inner = ((x - w/2) * W - l, (y - h/2) * H - t, (x + w/2) * W - l, (y + h/2) * H - t)
            crops.append((c, im.crop((int(l), int(t), int(r), int(b))), inner, p.name))
random.shuffle(crops)

fire_pool = fire_imgs[:]; random.shuffle(fire_pool)
for i in range(200):
    c, crop, inner, aname = crops[i % len(crops)]
    bgp = fire_pool[i % len(fire_pool)]
    bg = Image.open(bgp).convert("RGB")
    if max(bg.size) < 640:
        s = 640 / max(bg.size); bg = bg.resize((int(bg.width * s), int(bg.height * s)), Image.LANCZOS)
    BW, BH = bg.size
    target_w = random.uniform(0.25, 0.45) * BW
    s = min(target_w / crop.width, 0.7 * BH / crop.height)
    cw, ch = max(1, int(crop.width * s)), max(1, int(crop.height * s))
    cr = crop.resize((cw, ch), Image.LANCZOS)
    ox = random.randint(0, BW - cw); oy = random.randint(int((BH - ch) * 0.4), BH - ch)
    mask = Image.new("L", (cw, ch), 0)
    m = int(min(cw, ch) * 0.06)
    mask.paste(255, (m, m, cw - m, ch - m))
    bg.paste(cr, (ox, oy), mask.filter(ImageFilter.GaussianBlur(max(1, m // 2))))
    x1, y1, x2, y2 = [v * s for v in inner]
    x1, y1 = max(x1, m) + ox, max(y1, m) + oy
    x2, y2 = min(x2, cw - m) + ox, min(y2, ch - m) + oy
    lab = f"{c} {(x1+x2)/2/BW:.6f} {(y1+y2)/2/BH:.6f} {(x2-x1)/BW:.6f} {(y2-y1)/BH:.6f}"
    add(f"fire_animal_{i:04d}.jpg", bg, "fire_animal", [lab], True, f"{bgp.name} + {aname}")

# --- real single-condition images -------------------------------------------------
for i, p in enumerate(random.sample(fire_imgs, 100)):
    add(f"fire_only_{i:04d}.jpg", Image.open(p).convert("RGB"), "fire_only", [], False, p.name)
for i, p in enumerate(random.sample(animal_imgs, 100)):
    add(f"animal_only_{i:04d}.jpg", Image.open(p).convert("RGB"), "animal_only",
        [" ".join(b) for b in boxes(p)], False, p.name)
for i, p in enumerate(random.sample(nofire_imgs, 100)):
    add(f"none_{i:04d}.jpg", Image.open(p).convert("RGB"), "none", [], False, p.name)

with open(OUT / "fusion_labels.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["image", "scenario", "has_fire", "has_animal", "synthetic", "source_images"])
    w.writerows(rows)
print(len(rows), "fusion test images,", len(crops), "animal crops available")
